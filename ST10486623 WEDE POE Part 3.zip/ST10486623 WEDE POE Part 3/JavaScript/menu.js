// =======================
// Hamburger menu toggle
// =======================
document.addEventListener("DOMContentLoaded", () => {
  const toggle = document.getElementById("menu-toggle");
  const navLinks = document.getElementById("nav-links");

  if (toggle && navLinks) {
    toggle.addEventListener("click", () => {
      navLinks.classList.toggle("show");

      // Toggle icon
      if (navLinks.classList.contains("show")) {
        toggle.textContent = "✖"; // Close icon
      } else {
        toggle.textContent = "☰"; // Hamburger
      }
    });
  }

  // =======================
  // Form Validation (Enquiry)
  // =======================
  const form = document.querySelector("form");
  if (form) {
    form.addEventListener("submit", (event) => {
      event.preventDefault();

      const name = form.querySelector('input[name="name"]');
      const email = form.querySelector('input[name="email"]');
      const phone = form.querySelector('input[name="phone"]');
      const message = form.querySelector("textarea");

      let errors = [];

      // Name validation
      if (!name.value.trim()) {
        errors.push("Please enter your name.");
      }

      // Email validation
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email.value)) {
        errors.push("Please enter a valid email address.");
      }

      // Phone validation (South African format)
      const phonePattern = /^(\+27|0)[6-8][0-9]{8}$/;
      if (!phonePattern.test(phone.value)) {
        errors.push("Please enter a valid South African phone number.");
      }

      // Message validation
      if (message.value.trim().length < 10) {
        errors.push("Your message should be at least 10 characters long.");
      }

      if (errors.length > 0) {
        alert(errors.join("\\n"));
      } else {
        alert("Thank you, " + name.value + "! Your enquiry has been submitted.");
        form.reset();
      }
    });
  }

  // =======================
  // Leaderboard Highlight
  // =======================
  const leaderboard = document.querySelector(".leaderboard table");
  if (leaderboard) {
    const topRow = leaderboard.rows[1];
    if (topRow) {
      topRow.style.backgroundColor = "#22c55e";
      topRow.style.color = "#fff";
      setTimeout(() => {
        topRow.style.transition = "background-color 0.5s";
        topRow.style.backgroundColor = "#151b3d";
        topRow.style.color = "#f1f5f9";
      }, 3000);
    }
  }

  // =======================
  // Home Page Dynamic Message
  // =======================
  if (document.body.classList.contains("home")) {
    const main = document.querySelector("main");
    const dynamicMsg = document.createElement("div");
    dynamicMsg.textContent = "🔥 New tournaments coming soon! Stay tuned!";
    dynamicMsg.style.textAlign = "center";
    dynamicMsg.style.padding = "12px";
    dynamicMsg.style.color = "#f1f5f9";
    dynamicMsg.style.background = "#9333ea";
    dynamicMsg.style.marginTop = "20px";
    dynamicMsg.style.borderRadius = "8px";
    main.appendChild(dynamicMsg);

  }
// =======================
// Lightbox Gallery (Services Page)
// =======================
const lightbox = document.getElementById("lightbox");
const lightboxImg = document.getElementById("lightbox-img");
const closeBtn = document.querySelector(".close");

document.querySelectorAll(".service-card img").forEach((img) => {
  img.addEventListener("click", () => {
    lightbox.style.display = "block";
    lightboxImg.src = img.src;
  });
});

if (closeBtn) {
  closeBtn.addEventListener("click", () => {
    lightbox.style.display = "none";
  });
}

window.addEventListener("click", (e) => {
  if (e.target === lightbox) {
    lightbox.style.display = "none";
  }
});
// =======================
// Services Page Search Filter
// =======================
const searchInput = document.getElementById("service-search");
const serviceCards = document.querySelectorAll(".service-card");

if (searchInput && serviceCards.length > 0) {
  searchInput.addEventListener("keyup", () => {
    const query = searchInput.value.toLowerCase();

    serviceCards.forEach((card) => {
      const title = card.querySelector("h3").textContent.toLowerCase();
      const games = card.querySelector("ul").textContent.toLowerCase();

      // If card contains the search query, show it; otherwise, hide it
      if (title.includes(query) || games.includes(query)) {
        card.style.display = "block";
      } else {
        card.style.display = "none";
      }
    });
  });
}
// =======================
// Leaderboard Search Filter (by Rank or Name)
// =======================
const leaderboardSearch = document.getElementById("leaderboard-search");
const leaderboardTable = document.querySelector(".leaderboard table");

if (leaderboardSearch && leaderboardTable) {
  leaderboardSearch.addEventListener("keyup", () => {
    const query = leaderboardSearch.value.toLowerCase();
    const rows = leaderboardTable.getElementsByTagName("tr");

    let hasResults = false;

    for (let i = 1; i < rows.length; i++) { // skip header row
      const rank = rows[i].cells[0]?.textContent.toLowerCase() || "";
      const playerName = rows[i].cells[1]?.textContent.toLowerCase() || "";

      // Match by either rank or name
      if (rank.includes(query) || playerName.includes(query)) {
        rows[i].style.display = "";
        hasResults = true;
      } else {
        rows[i].style.display = "none";
      }
    }

    // Optional: show "No results" message
    const noResultMsg = document.getElementById("no-results");
    if (!hasResults && query.length > 0) {
      if (!noResultMsg) {
        const msg = document.createElement("p");
        msg.id = "no-results";
        msg.textContent = "⚠️ No players found for that search.";
        msg.style.textAlign = "center";
        msg.style.color = "#a78bfa";
        msg.style.marginTop = "10px";
        leaderboardTable.parentNode.appendChild(msg);
      }
    } else if (hasResults && noResultMsg) {
      noResultMsg.remove();
    } else if (query.length === 0 && noResultMsg) {
      noResultMsg.remove();
    }
  });
}
// =======================
// Contact Form - Formspree Submission
// =======================
const contactForm = document.getElementById("contactForm");

if (contactForm) {
  contactForm.addEventListener("submit", async (e) => {
    e.preventDefault();
    const formData = new FormData(contactForm);

    try {
      const response = await fetch(contactForm.action, {
        method: "POST",
        body: formData,
        headers: { Accept: "application/json" },
      });

      if (response.ok) {
        alert("🎉 Thank you! Your message has been sent successfully.");
        contactForm.reset();
      } else {
        alert("⚠️ Oops! There was an issue sending your message. Please try again.");
      }
    } catch (error) {
      alert("❌ Network error. Please check your connection and try again.");
    }
  });
}
});